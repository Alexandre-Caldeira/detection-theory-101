clear all, close all, clc

%plotar valores cr�ticos
alfa = 0.05;
M= 300;
tamanho_janela = 100; 
f = 10; 
fs = 100; 
N = M *tamanho_janela; %dura��o do sinal

amplitude_ruido = 20; 
A =1;

%
[~,VC_teorico] = VC_CSM(M,alfa,2);
s(:,1) = sin(2*pi*f/fs*[0:(N-1)]);
x = A *s + amplitude_ruido*randn(N,1); 

ord_CSM = CSM(x,tamanho_janela,M);


f = [0:tamanho_janela/2]*fs/tamanho_janela;
figure 
lw = 1.5;
subplot(2,1,1)
plot([1:100],x(1:100),'-k','LineWidth',lw)
subplot(2,1,2)
plot(f,ord_CSM(1:(tamanho_janela/2+1)),'-k','LineWidth',lw)
hold on 
plot([0 N],[ VC_teorico,VC_teorico],'-r','LineWidth',lw)
xlim([f(2) f(end)])
xlabel('Frequ�ncia','fontsize',12)
ylabel('CSM','fontsize',12)
legend({'CSM';'Valor Cr�tico'},'edgecolor','none','fontsize',12)

% FP = mean(ord_LFT > VC_teorico)


% 

